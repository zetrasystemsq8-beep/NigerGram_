// lib/features/video_feed/repository/interaction_repository.dart

import 'package:cloud_firestore/cloud_firestore.dart';

class InteractionRepository {
  final FirebaseFirestore _firestore;

  InteractionRepository({FirebaseFirestore? firestore}) : _firestore = firestore ?? FirebaseFirestore.instance;

  /// Toggle like for [videoId] by [userId].
  /// Returns the new like status (true if liked, false if unliked).
  /// Uses transactional atomic operations to ensure consistency.
  /// Maintains both a `likes` subcollection and a `likedBy` array on the video document.
  Future<bool> toggleLike(String videoId, String userId) async {
    final videoRef = _firestore.collection('videos').doc(videoId);
    final likeRef = videoRef.collection('likes').doc(userId);

    return _firestore.runTransaction<bool>((tx) async {
      final likeSnap = await tx.get(likeRef);
      final videoSnap = await tx.get(videoRef);

      List<dynamic> likedBy = [];
      if (videoSnap.exists) {
        likedBy = List.from((videoSnap.data()?['likedBy'] as List<dynamic>?) ?? []);
      }

      if (likeSnap.exists) {
        // Currently liked - remove like
        tx.delete(likeRef);
        likedBy.removeWhere((id) => id == userId);
        tx.update(videoRef, {
          'likeCount': FieldValue.increment(-1),
          'likedBy': likedBy,
        });
        return false;
      } else {
        // Not liked - add like
        tx.set(likeRef, {
          'userId': userId,
          'timestamp': FieldValue.serverTimestamp(),
        });
        if (!likedBy.contains(userId)) {
          likedBy.add(userId);
        }
        tx.update(videoRef, {
          'likeCount': FieldValue.increment(1),
          'likedBy': likedBy,
        });
        return true;
      }
    });
  }

  /// Toggle save/bookmark for [videoId] by [userId].
  /// Returns the new save status (true if saved, false if unsaved).
  /// Uses a transactional operation to maintain `savedBy` array on video document.
  Future<bool> toggleSave(String videoId, String userId) async {
    final videoRef = _firestore.collection('videos').doc(videoId);
    final saveRef = videoRef.collection('saves').doc(userId);

    return _firestore.runTransaction<bool>((tx) async {
      final saveSnap = await tx.get(saveRef);
      final videoSnap = await tx.get(videoRef);

      List<dynamic> savedBy = [];
      if (videoSnap.exists) {
        savedBy = List.from((videoSnap.data()?['savedBy'] as List<dynamic>?) ?? []);
      }

      if (saveSnap.exists) {
        // Currently saved - remove save
        tx.delete(saveRef);
        savedBy.removeWhere((id) => id == userId);
        tx.update(videoRef, {'savedBy': savedBy});
        return false;
      } else {
        // Not saved - add save
        tx.set(saveRef, {
          'userId': userId,
          'timestamp': FieldValue.serverTimestamp(),
        });
        if (!savedBy.contains(userId)) {
          savedBy.add(userId);
        }
        tx.update(videoRef, {'savedBy': savedBy});
        return true;
      }
    });
  }

  /// Adds a comment or reply under videos/{videoId}/comments and increments
  /// commentCount. Pass [parentId] to create a reply to a top-level comment
  /// (one level of nesting only). [mentionedUsernames] are stored for
  /// display/notification purposes.
  Future<String> addComment(
    String videoId,
    String userId,
    String username,
    String text, {
    String? userAvatar,
    String? parentId,
    List<String> mentionedUsernames = const [],
  }) async {
    final videoRef = _firestore.collection('videos').doc(videoId);
    final commentsRef = videoRef.collection('comments');
    final newDoc = commentsRef.doc();

    final commentData = {
      'id': newDoc.id,
      'videoId': videoId,
      'parentId': parentId,
      'userId': userId,
      'username': username,
      'userAvatar': userAvatar ?? '',
      'text': text,
      'mentionedUsernames': mentionedUsernames,
      'createdAt': FieldValue.serverTimestamp(),
      'likeCount': 0,
      'likedBy': <String>[],
      'replyCount': 0,
      'isPinned': false,
    };

    await _firestore.runTransaction((tx) async {
      final videoSnap = await tx.get(videoRef);
      if (!videoSnap.exists) {
        throw Exception('Video not found');
      }

      DocumentReference? parentRef;
      if (parentId != null) {
        parentRef = commentsRef.doc(parentId);
        final parentSnap = await tx.get(parentRef);
        if (!parentSnap.exists) {
          throw Exception('Original comment not found');
        }
      }

      tx.set(newDoc, commentData);
      tx.update(videoRef, {'commentCount': FieldValue.increment(1)});
      if (parentRef != null) {
        tx.update(parentRef, {'replyCount': FieldValue.increment(1)});
      }
    });

    return newDoc.id;
  }

  /// Stream of top-level comments (parentId == null) for a video, pinned
  /// comment first, then newest first.
  Stream<QuerySnapshot> getCommentsStream(String videoId, {int limit = 50}) {
    return _firestore
        .collection('videos')
        .doc(videoId)
        .collection('comments')
        .where('parentId', isNull: true)
        .orderBy('isPinned', descending: true)
        .orderBy('createdAt', descending: true)
        .limit(limit)
        .snapshots();
  }

  /// Paginated top-level comments, starting after [lastDocument].
  Future<QuerySnapshot> getCommentsPaginated(
    String videoId, {
    DocumentSnapshot? lastDocument,
    int limit = 20,
  }) async {
    var query = _firestore
        .collection('videos')
        .doc(videoId)
        .collection('comments')
        .where('parentId', isNull: true)
        .orderBy('isPinned', descending: true)
        .orderBy('createdAt', descending: true);

    if (lastDocument != null) {
      query = query.startAfterDocument(lastDocument);
    }

    return query.limit(limit).get();
  }

  /// Real-time stream of replies belonging to [parentId], oldest first.
  Stream<QuerySnapshot> getRepliesStream(String videoId, String parentId, {int limit = 100}) {
    return _firestore
        .collection('videos')
        .doc(videoId)
        .collection('comments')
        .where('parentId', isEqualTo: parentId)
        .orderBy('createdAt', descending: false)
        .limit(limit)
        .snapshots();
  }

  /// Toggle like for a comment by [userId]. Maintains a `likes` subcollection
  /// (source of truth for duplicate prevention) plus a denormalized
  /// `likedBy` array + `likeCount` on the comment doc for fast reads.
  /// Returns the new like status.
  Future<bool> toggleCommentLike(String videoId, String commentId, String userId) async {
    final commentRef = _firestore
        .collection('videos')
        .doc(videoId)
        .collection('comments')
        .doc(commentId);
    final likeRef = commentRef.collection('likes').doc(userId);

    return _firestore.runTransaction<bool>((tx) async {
      final likeSnap = await tx.get(likeRef);
      final commentSnap = await tx.get(commentRef);
      if (!commentSnap.exists) throw Exception('Comment not found');

      List<dynamic> likedBy = List.from(
        (commentSnap.data()?['likedBy'] as List<dynamic>?) ?? [],
      );

      if (likeSnap.exists) {
        tx.delete(likeRef);
        likedBy.removeWhere((id) => id == userId);
        tx.update(commentRef, {
          'likeCount': FieldValue.increment(-1),
          'likedBy': likedBy,
        });
        return false;
      } else {
        tx.set(likeRef, {
          'userId': userId,
          'timestamp': FieldValue.serverTimestamp(),
        });
        if (!likedBy.contains(userId)) likedBy.add(userId);
        tx.update(commentRef, {
          'likeCount': FieldValue.increment(1),
          'likedBy': likedBy,
        });
        return true;
      }
    });
  }

  /// Deletes a comment. Only the comment author or the video's creator may
  /// call this (callers should also rely on Firestore security rules as the
  /// authoritative check). Deleting a top-level comment cascades to delete
  /// all of its replies and decrements counters accordingly.
  Future<void> deleteComment({
    required String videoId,
    required String commentId,
    required String requestingUserId,
    required bool requesterIsVideoCreator,
  }) async {
    final videoRef = _firestore.collection('videos').doc(videoId);
    final commentsRef = videoRef.collection('comments');
    final commentRef = commentsRef.doc(commentId);

    final commentSnap = await commentRef.get();
    if (!commentSnap.exists) return;
    final data = commentSnap.data() as Map<String, dynamic>;
    final ownerId = data['userId'] as String? ?? '';
    final isPinned = data['isPinned'] as bool? ?? false;
    final parentId = data['parentId'] as String?;

    if (ownerId != requestingUserId && !requesterIsVideoCreator) {
      throw Exception('You can only delete your own comments');
    }

    final batch = _firestore.batch();
    int totalDeleted = 1;

    if (parentId == null) {
      // Top-level comment: cascade-delete replies.
      final replies = await commentsRef.where('parentId', isEqualTo: commentId).get();
      for (final reply in replies.docs) {
        batch.delete(reply.reference);
      }
      totalDeleted += replies.docs.length;
    } else {
      // Reply: decrement parent's replyCount.
      batch.update(commentsRef.doc(parentId), {'replyCount': FieldValue.increment(-1)});
    }

    batch.delete(commentRef);
    batch.update(videoRef, {'commentCount': FieldValue.increment(-totalDeleted)});
    if (isPinned) {
      batch.update(videoRef, {'pinnedCommentId': FieldValue.delete()});
    }

    await batch.commit();
  }

  /// Pins [commentId] as the single pinned comment for [videoId], unpinning
  /// any previously pinned comment. Only the video creator should call this;
  /// Firestore rules enforce this server-side.
  Future<void> pinComment({
    required String videoId,
    required String commentId,
  }) async {
    final videoRef = _firestore.collection('videos').doc(videoId);
    final commentsRef = videoRef.collection('comments');
    final newPinRef = commentsRef.doc(commentId);

    await _firestore.runTransaction((tx) async {
      final videoSnap = await tx.get(videoRef);
      if (!videoSnap.exists) throw Exception('Video not found');
      final previousPinnedId = videoSnap.data()?['pinnedCommentId'] as String?;

      if (previousPinnedId != null && previousPinnedId != commentId) {
        final prevRef = commentsRef.doc(previousPinnedId);
        final prevSnap = await tx.get(prevRef);
        if (prevSnap.exists) {
          tx.update(prevRef, {'isPinned': false});
        }
      }

      tx.update(newPinRef, {'isPinned': true});
      tx.update(videoRef, {'pinnedCommentId': commentId});
    });
  }

  /// Unpins the currently pinned comment, if any.
  Future<void> unpinComment({
    required String videoId,
    required String commentId,
  }) async {
    final videoRef = _firestore.collection('videos').doc(videoId);
    final commentRef = videoRef.collection('comments').doc(commentId);

    final batch = _firestore.batch();
    batch.update(commentRef, {'isPinned': false});
    batch.update(videoRef, {'pinnedCommentId': FieldValue.delete()});
    await batch.commit();
  }

  /// Submits a report for a comment into the top-level `reports` collection.
  Future<void> reportComment({
    required String commentId,
    required String videoId,
    required String reporterId,
    required String reason,
  }) async {
    await _firestore.collection('reports').add({
      'commentId': commentId,
      'videoId': videoId,
      'reporterId': reporterId,
      'reason': reason,
      'timestamp': FieldValue.serverTimestamp(),
      'status': 'pending',
    });
  }

  /// Searches the `users` collection for usernames starting with [query], for
  /// @mention autocomplete. Expects `username` to be stored lowercase.
  Future<QuerySnapshot> searchUsernames(String query, {int limit = 5}) async {
    final normalized = query.trim().toLowerCase();
    if (normalized.isEmpty) {
      return _firestore.collection('users').limit(0).get();
    }
    return _firestore
        .collection('users')
        .orderBy('username')
        .startAt([normalized])
        .endAt(['$normalized\uf8ff'])
        .limit(limit)
        .get();
  }

  /// Check if current user has liked a specific video.
  /// Returns true if userId exists in the video's likedBy array.
  Future<bool> isVideoLiked(String videoId, String userId) async {
    try {
      final doc = await _firestore.collection('videos').doc(videoId).get();
      if (!doc.exists) return false;
      final likedBy = (doc.data()?['likedBy'] as List<dynamic>?) ?? [];
      return likedBy.contains(userId);
    } catch (_) {
      return false;
    }
  }

  /// Check if current user has saved a specific video.
  /// Returns true if userId exists in the video's savedBy array.
  Future<bool> isVideoSaved(String videoId, String userId) async {
    try {
      final doc = await _firestore.collection('videos').doc(videoId).get();
      if (!doc.exists) return false;
      final savedBy = (doc.data()?['savedBy'] as List<dynamic>?) ?? [];
      return savedBy.contains(userId);
    } catch (_) {
      return false;
    }
  }

  /// Get a live stream of a video's interaction data (likes, comments, saves).
  /// Useful for UI to stay in sync with backend changes.
  Stream<DocumentSnapshot> getVideoInteractionsStream(String videoId) {
    return _firestore.collection('videos').doc(videoId).snapshots();
  }
}
