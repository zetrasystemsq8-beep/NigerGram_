// lib/features/video_feed/presentation/view/widgets/comment_tile.dart
import 'package:flutter/material.dart';

import 'package:nigergram/features/video_feed/domain/entities/comment_entity.dart';
import 'package:nigergram/features/video_feed/presentation/view/widgets/comment_mention_text.dart';

const _kAccent = Color(0xFF00C853);
const _kLike = Color(0xFFFF2D55);

class CommentTile extends StatelessWidget {
  const CommentTile({
    required this.comment,
    required this.currentUserId,
    required this.isVideoCreator,
    required this.onLikeToggle,
    required this.onReply,
    this.onDelete,
    this.onPin,
    this.onReport,
    this.isReply = false,
    this.replyCount = 0,
    this.repliesExpanded = false,
    this.repliesLoading = false,
    this.onToggleReplies,
    super.key,
  });

  final CommentEntity comment;
  final String? currentUserId;
  final bool isVideoCreator;
  final VoidCallback onLikeToggle;
  final VoidCallback onReply;
  final VoidCallback? onDelete;
  final VoidCallback? onPin;
  final VoidCallback? onReport;
  final bool isReply;
  final int replyCount;
  final bool repliesExpanded;
  final bool repliesLoading;
  final VoidCallback? onToggleReplies;

  bool get _canDelete => currentUserId != null && (currentUserId == comment.userId || isVideoCreator);

  String _formatTime(DateTime t) {
    final diff = DateTime.now().difference(t);
    if (diff.inSeconds < 60) return 'now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m';
    if (diff.inHours < 24) return '${diff.inHours}h';
    if (diff.inDays < 7) return '${diff.inDays}d';
    return '${(diff.inDays / 7).floor()}w';
  }

  void _showOptionsSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF181818),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (sheetContext) {
        return SafeArea(
          child: Wrap(
            children: [
              if (isVideoCreator && !isReply && onPin != null)
                ListTile(
                  leading: Icon(comment.isPinned ? Icons.push_pin_outlined : Icons.push_pin, color: Colors.white70),
                  title: Text(
                    comment.isPinned ? 'Unpin comment' : 'Pin comment',
                    style: const TextStyle(color: Colors.white),
                  ),
                  onTap: () {
                    Navigator.pop(sheetContext);
                    onPin?.call();
                  },
                ),
              if (_canDelete && onDelete != null)
                ListTile(
                  leading: const Icon(Icons.delete_outline, color: Color(0xFFFF1744)),
                  title: const Text('Delete comment', style: TextStyle(color: Color(0xFFFF1744))),
                  onTap: () {
                    Navigator.pop(sheetContext);
                    _confirmDelete(context);
                  },
                ),
              if (currentUserId != null && currentUserId != comment.userId && onReport != null)
                ListTile(
                  leading: const Icon(Icons.flag_outlined, color: Colors.white70),
                  title: const Text('Report comment', style: TextStyle(color: Colors.white)),
                  onTap: () {
                    Navigator.pop(sheetContext);
                    onReport?.call();
                  },
                ),
              ListTile(
                leading: const Icon(Icons.close, color: Colors.white38),
                title: const Text('Cancel', style: TextStyle(color: Colors.white38)),
                onTap: () => Navigator.pop(sheetContext),
              ),
            ],
          ),
        );
      },
    );
  }

  void _confirmDelete(BuildContext context) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: const Color(0xFF181818),
        title: const Text('Delete comment?', style: TextStyle(color: Colors.white)),
        content: const Text(
          'This action cannot be undone.',
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancel', style: TextStyle(color: Colors.white70)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(dialogContext);
              onDelete?.call();
            },
            child: const Text('Delete', style: TextStyle(color: Color(0xFFFF1744))),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isLiked = comment.isLikedBy(currentUserId);
    final avatar = comment.userAvatar;

    return Padding(
      padding: EdgeInsets.only(left: isReply ? 44 : 0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            radius: isReply ? 14 : 18,
            backgroundColor: Colors.white10,
            backgroundImage: avatar.isNotEmpty ? NetworkImage(avatar) : null,
            child: avatar.isEmpty
                ? Text(
                    comment.username.isNotEmpty ? comment.username.replaceFirst('@', '')[0].toUpperCase() : 'U',
                    style: TextStyle(color: Colors.white70, fontSize: isReply ? 11 : 12, fontWeight: FontWeight.bold),
                  )
                : null,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      comment.username,
                      style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.bold, fontSize: 12),
                    ),
                    if (comment.isPinned) ...[
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: _kAccent.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.push_pin, size: 10, color: _kAccent),
                            SizedBox(width: 3),
                            Text('Pinned', style: TextStyle(color: _kAccent, fontSize: 9, fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 4),
                CommentMentionText(text: comment.text),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Text(_formatTime(comment.createdAt), style: const TextStyle(fontSize: 10, color: Colors.white38)),
                    const SizedBox(width: 16),
                    GestureDetector(
                      onTap: onReply,
                      child: const Text('Reply', style: TextStyle(fontSize: 11, color: Colors.white38, fontWeight: FontWeight.w600)),
                    ),
                    const SizedBox(width: 16),
                    GestureDetector(
                      onTap: () => _showOptionsSheet(context),
                      child: const Icon(Icons.more_horiz, size: 16, color: Colors.white24),
                    ),
                  ],
                ),
                if (!isReply && replyCount > 0) ...[
                  const SizedBox(height: 8),
                  GestureDetector(
                    onTap: onToggleReplies,
                    child: Row(
                      children: [
                        Container(width: 24, height: 1, color: Colors.white24),
                        const SizedBox(width: 8),
                        Text(
                          repliesExpanded ? 'Hide replies' : 'View $replyCount ${replyCount == 1 ? 'reply' : 'replies'}',
                          style: const TextStyle(fontSize: 12, color: Colors.white54, fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(width: 6),
                        if (repliesLoading)
                          const SizedBox(
                            width: 10,
                            height: 10,
                            child: CircularProgressIndicator(strokeWidth: 1.5, color: Colors.white38),
                          )
                        else
                          Icon(
                            repliesExpanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                            size: 14,
                            color: Colors.white54,
                          ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(width: 8),
          _AnimatedCommentHeart(isLiked: isLiked, likeCount: comment.likeCount, onTap: onLikeToggle),
        ],
      ),
    );
  }
}

class _AnimatedCommentHeart extends StatefulWidget {
  const _AnimatedCommentHeart({
    required this.isLiked,
    required this.likeCount,
    required this.onTap,
  });

  final bool isLiked;
  final int likeCount;
  final VoidCallback onTap;

  @override
  State<_AnimatedCommentHeart> createState() => _AnimatedCommentHeartState();
}

class _AnimatedCommentHeartState extends State<_AnimatedCommentHeart> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 280),
  );
  late final Animation<double> _scale = TweenSequence<double>([
    TweenSequenceItem(tween: Tween(begin: 1.0, end: 1.4).chain(CurveTween(curve: Curves.easeOut)), weight: 50),
    TweenSequenceItem(tween: Tween(begin: 1.4, end: 1.0).chain(CurveTween(curve: Curves.easeIn)), weight: 50),
  ]).animate(_controller);

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _handleTap() {
    _controller.forward(from: 0);
    widget.onTap();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _handleTap,
      behavior: HitTestBehavior.opaque,
      child: Column(
        children: [
          ScaleTransition(
            scale: _scale,
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 180),
              transitionBuilder: (child, animation) => ScaleTransition(scale: animation, child: child),
              child: Icon(
                widget.isLiked ? Icons.favorite : Icons.favorite_border,
                key: ValueKey(widget.isLiked),
                size: 16,
                color: widget.isLiked ? _kLike : Colors.white38,
              ),
            ),
          ),
          if (widget.likeCount > 0) ...[
            const SizedBox(height: 2),
            Text(
              '${widget.likeCount}',
              style: TextStyle(fontSize: 10, color: widget.isLiked ? _kLike : Colors.white38),
            ),
          ],
        ],
      ),
    );
  }
}
