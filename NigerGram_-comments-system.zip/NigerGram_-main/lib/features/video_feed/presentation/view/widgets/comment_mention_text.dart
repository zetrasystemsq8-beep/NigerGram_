// lib/features/video_feed/presentation/view/widgets/comment_mention_text.dart
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

/// Renders comment/reply body text, turning `@username` tokens into
/// tappable, highlighted spans that navigate to the mentioned user's
/// profile.
class CommentMentionText extends StatelessWidget {
  const CommentMentionText({
    required this.text,
    this.style,
    this.mentionColor = const Color(0xFF00C853),
    super.key,
  });

  final String text;
  final TextStyle? style;
  final Color mentionColor;

  @override
  Widget build(BuildContext context) {
    final baseStyle = style ?? const TextStyle(color: Colors.white, fontSize: 13, height: 1.35);
    return RichText(
      text: TextSpan(style: baseStyle, children: _buildSpans(context, baseStyle)),
    );
  }

  List<TextSpan> _buildSpans(BuildContext context, TextStyle baseStyle) {
    final spans = <TextSpan>[];
    final regex = RegExp(r'@(\w+)');
    int lastEnd = 0;

    for (final match in regex.allMatches(text)) {
      if (match.start > lastEnd) {
        spans.add(TextSpan(text: text.substring(lastEnd, match.start)));
      }
      final username = match.group(1)!;
      spans.add(
        TextSpan(
          text: '@$username',
          style: baseStyle.copyWith(color: mentionColor, fontWeight: FontWeight.w600),
          recognizer: TapGestureRecognizer()
            ..onTap = () => GoRouter.of(context).push('/profile/$username'),
        ),
      );
      lastEnd = match.end;
    }

    if (lastEnd < text.length) {
      spans.add(TextSpan(text: text.substring(lastEnd)));
    }
    return spans;
  }
}
