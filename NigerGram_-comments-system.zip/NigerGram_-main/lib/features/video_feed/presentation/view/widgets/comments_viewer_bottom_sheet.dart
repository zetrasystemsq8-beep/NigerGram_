// lib/features/video_feed/presentation/view/widgets/comments_viewer_bottom_sheet.dart
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:nigergram/features/video_feed/domain/entities/comment_entity.dart';
import 'package:nigergram/features/video_feed/presentation/bloc/comment_cubit.dart';
import 'package:nigergram/features/video_feed/presentation/bloc/comment_state.dart';
import 'package:nigergram/features/video_feed/presentation/view/widgets/comment_tile.dart';

const _kBg = Color(0xFF0F0F12);
const _kAccent = Color(0xFF00C853);

class CommentsViewerBottomSheet extends StatelessWidget {
  final String videoId;
  final String videoCreatorId;

  const CommentsViewerBottomSheet({
    required this.videoId,
    required this.videoCreatorId,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => CommentCubit(videoId: videoId, videoCreatorId: videoCreatorId),
      child: const _CommentsSheetBody(),
    );
  }
}

class _CommentsSheetBody extends StatefulWidget {
  const _CommentsSheetBody();

  @override
  State<_CommentsSheetBody> createState() => _CommentsSheetBodyState();
}

class _CommentsSheetBodyState extends State<_CommentsSheetBody> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
    _controller.addListener(_onTextChanged);
  }

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scrollController.position.pixels >= _scrollController.position.maxScrollExtent - 120) {
      context.read<CommentCubit>().loadMoreComments();
    }
  }

  void _onTextChanged() {
    context.read<CommentCubit>().onComposerTextChanged(_controller.text, _controller.selection.baseOffset < 0 ? _controller.text.length : _controller.selection.baseOffset);
  }

  void _insertMention(MentionUserEntity user) {
    final text = _controller.text;
    final cursor = _controller.selection.baseOffset < 0 ? text.length : _controller.selection.baseOffset;
    final upToCursor = text.substring(0, cursor);
    final atIndex = upToCursor.lastIndexOf('@');
    if (atIndex == -1) return;

    final newText = '${text.substring(0, atIndex)}@${user.username} ${text.substring(cursor)}';
    final newCursor = atIndex + user.username.length + 2;
    _controller.value = TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: newCursor),
    );
    context.read<CommentCubit>().clearMentionSuggestions();
  }

  void _submit() {
    final cubit = context.read<CommentCubit>();
    if (FirebaseAuth.instance.currentUser == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please sign in to comment'), backgroundColor: Colors.redAccent),
      );
      return;
    }
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    cubit.postComment(text);
    _controller.clear();
    cubit.clearMentionSuggestions();
    Future.delayed(const Duration(milliseconds: 150), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(0, duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
      }
    });
  }

  Future<void> _showReportSheet(BuildContext context, CommentEntity comment) async {
    final cubit = context.read<CommentCubit>();
    const reasons = ['Spam', 'Harassment or bullying', 'Hate speech', 'Misinformation', 'Other'];
    final reason = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: const Color(0xFF181818),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (sheetContext) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text('Report comment', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
              ...reasons.map(
                (r) => ListTile(
                  title: Text(r, style: const TextStyle(color: Colors.white)),
                  onTap: () => Navigator.pop(sheetContext, r),
                ),
              ),
            ],
          ),
        );
      },
    );
    if (reason == null) return;
    final success = await cubit.reportComment(comment, reason);
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(success ? 'Comment reported' : 'Failed to report comment'),
          backgroundColor: success ? _kAccent : Colors.redAccent,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    final bottomInset = mediaQuery.viewInsets.bottom;

    return Container(
      decoration: const BoxDecoration(
        color: _kBg,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: SafeArea(
        child: Padding(
          padding: EdgeInsets.only(bottom: bottomInset),
          child: FractionallySizedBox(
            heightFactor: 0.85,
            child: Column(
              children: [
                const SizedBox(height: 12),
                Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2)),
                ),
                const SizedBox(height: 16),
                BlocBuilder<CommentCubit, CommentState>(
                  buildWhen: (a, b) => a.comments.length != b.comments.length,
                  builder: (context, state) => Text(
                    '${state.comments.length} Comments',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
                  ),
                ),
                const SizedBox(height: 12),
                const Divider(height: 1, color: Colors.white10),
                Expanded(child: _buildCommentsList(context)),
                const Divider(height: 1, color: Colors.white10),
                _buildReplyBanner(context),
                _buildMentionSuggestions(context),
                _buildInputArea(context),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildReplyBanner(BuildContext context) {
    return BlocBuilder<CommentCubit, CommentState>(
      buildWhen: (a, b) => a.replyingToCommentId != b.replyingToCommentId,
      builder: (context, state) {
        if (state.replyingToUsername == null) return const SizedBox.shrink();
        return Container(
          width: double.infinity,
          color: Colors.white.withOpacity(0.03),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  'Replying to ${state.replyingToUsername}',
                  style: const TextStyle(color: Colors.white54, fontSize: 12),
                ),
              ),
              GestureDetector(
                onTap: () => context.read<CommentCubit>().cancelReply(),
                child: const Icon(Icons.close, size: 16, color: Colors.white38),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildMentionSuggestions(BuildContext context) {
    return BlocBuilder<CommentCubit, CommentState>(
      buildWhen: (a, b) => a.mentionSuggestions != b.mentionSuggestions || a.isSearchingMentions != b.isSearchingMentions,
      builder: (context, state) {
        if (!state.isSearchingMentions && state.mentionSuggestions.isEmpty) {
          return const SizedBox.shrink();
        }
        return AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          constraints: const BoxConstraints(maxHeight: 180),
          decoration: const BoxDecoration(
            color: Color(0xFF181818),
            border: Border(top: BorderSide(color: Colors.white12)),
          ),
          child: state.isSearchingMentions && state.mentionSuggestions.isEmpty
              ? const Padding(
                  padding: EdgeInsets.all(12),
                  child: SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2, color: _kAccent),
                  ),
                )
              : ListView.builder(
                  shrinkWrap: true,
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  itemCount: state.mentionSuggestions.length,
                  itemBuilder: (context, index) {
                    final user = state.mentionSuggestions[index];
                    return ListTile(
                      dense: true,
                      leading: CircleAvatar(
                        radius: 14,
                        backgroundColor: Colors.white10,
                        backgroundImage: user.avatarUrl.isNotEmpty ? NetworkImage(user.avatarUrl) : null,
                        child: user.avatarUrl.isEmpty
                            ? Text(
                                user.username.isNotEmpty ? user.username[0].toUpperCase() : '?',
                                style: const TextStyle(color: Colors.white70, fontSize: 11),
                              )
                            : null,
                      ),
                      title: Text('@${user.username}', style: const TextStyle(color: Colors.white, fontSize: 13)),
                      onTap: () => _insertMention(user),
                    );
                  },
                ),
        );
      },
    );
  }

  Widget _buildInputArea(BuildContext context) {
    return Container(
      color: _kBg,
      padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8),
      child: BlocBuilder<CommentCubit, CommentState>(
        buildWhen: (a, b) => a.isPosting != b.isPosting,
        builder: (context, state) {
          return Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _controller,
                  focusNode: _focusNode,
                  textInputAction: TextInputAction.send,
                  onSubmitted: (_) => state.isPosting ? null : _submit(),
                  enabled: !state.isPosting,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                  decoration: InputDecoration(
                    hintText: 'Add a comment... use @ to mention',
                    hintStyle: const TextStyle(color: Colors.white38, fontSize: 13),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    isDense: true,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(24),
                      borderSide: BorderSide.none,
                    ),
                    filled: true,
                    fillColor: Colors.white.withOpacity(0.04),
                  ),
                  minLines: 1,
                  maxLines: 4,
                ),
              ),
              const SizedBox(width: 8),
              IconButton(
                icon: state.isPosting
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(color: _kAccent, strokeWidth: 2),
                      )
                    : const Icon(Icons.send_rounded, color: _kAccent),
                onPressed: state.isPosting ? null : _submit,
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildCommentsList(BuildContext context) {
    return BlocBuilder<CommentCubit, CommentState>(
      builder: (context, state) {
        if (state.comments.isEmpty && !state.isLoadingInitial) {
          return const Center(
            child: Text('No comments yet — be first!', style: TextStyle(color: Colors.white38, fontSize: 13)),
          );
        }
        if (state.comments.isEmpty && state.isLoadingInitial) {
          return const Center(child: CircularProgressIndicator(color: _kAccent, strokeWidth: 2));
        }

        final cubit = context.read<CommentCubit>();

        return ListView.separated(
          controller: _scrollController,
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
          itemCount: state.hasMore ? state.comments.length + 1 : state.comments.length,
          separatorBuilder: (_, __) => const SizedBox(height: 16),
          itemBuilder: (context, index) {
            if (index >= state.comments.length) {
              return const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Center(child: CircularProgressIndicator(color: _kAccent, strokeWidth: 2)),
              );
            }

            final comment = state.comments[index];
            final expanded = state.expandedParents.contains(comment.id);
            final repliesLoading = state.loadingReplyParents.contains(comment.id);
            final replies = state.repliesByParent[comment.id] ?? const <CommentEntity>[];

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CommentTile(
                  comment: comment,
                  currentUserId: cubit.currentUserId,
                  isVideoCreator: cubit.isVideoCreator,
                  replyCount: comment.replyCount,
                  repliesExpanded: expanded,
                  repliesLoading: repliesLoading,
                  onToggleReplies: () => cubit.toggleReplies(comment.id),
                  onLikeToggle: () => cubit.toggleCommentLike(comment),
                  onReply: () {
                    cubit.startReplyTo(comment.id, comment.username);
                    _focusNode.requestFocus();
                  },
                  onDelete: () => cubit.deleteComment(comment),
                  onPin: () => cubit.pinComment(comment),
                  onReport: () => _showReportSheet(context, comment),
                ),
                if (expanded && replies.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  ...replies.map(
                    (reply) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: CommentTile(
                        comment: reply,
                        currentUserId: cubit.currentUserId,
                        isVideoCreator: cubit.isVideoCreator,
                        isReply: true,
                        onLikeToggle: () => cubit.toggleCommentLike(reply),
                        onReply: () {
                          cubit.startReplyTo(comment.id, reply.username);
                          _focusNode.requestFocus();
                        },
                        onDelete: () => cubit.deleteComment(reply),
                        onReport: () => _showReportSheet(context, reply),
                      ),
                    ),
                  ),
                ],
              ],
            );
          },
        );
      },
    );
  }
}
