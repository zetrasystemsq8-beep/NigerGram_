// lib/features/video_feed/presentation/bloc/comment_state.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:equatable/equatable.dart';
import 'package:nigergram/features/video_feed/domain/entities/comment_entity.dart';

class CommentState extends Equatable {
  const CommentState({
    this.isLoadingInitial = false,
    this.isLoadingMore = false,
    this.isPosting = false,
    this.hasMore = true,
    this.errorMessage = '',
    this.comments = const [],
    this.lastDocument,
    this.repliesByParent = const {},
    this.expandedParents = const {},
    this.loadingReplyParents = const {},
    this.replyingToCommentId,
    this.replyingToUsername,
    this.mentionSuggestions = const [],
    this.isSearchingMentions = false,
    this.pinnedCommentId,
  });

  final bool isLoadingInitial;
  final bool isLoadingMore;
  final bool isPosting;
  final bool hasMore;
  final String errorMessage;
  final List<CommentEntity> comments;
  final DocumentSnapshot? lastDocument;

  /// Replies keyed by their parent comment id.
  final Map<String, List<CommentEntity>> repliesByParent;

  /// Parent comment ids whose replies are currently expanded/visible.
  final Set<String> expandedParents;

  /// Parent comment ids currently fetching their first page of replies.
  final Set<String> loadingReplyParents;

  /// If set, the composer is replying to this comment id (and username).
  final String? replyingToCommentId;
  final String? replyingToUsername;

  final List<MentionUserEntity> mentionSuggestions;
  final bool isSearchingMentions;

  final String? pinnedCommentId;

  CommentState copyWith({
    bool? isLoadingInitial,
    bool? isLoadingMore,
    bool? isPosting,
    bool? hasMore,
    String? errorMessage,
    List<CommentEntity>? comments,
    DocumentSnapshot? lastDocument,
    bool clearLastDocument = false,
    Map<String, List<CommentEntity>>? repliesByParent,
    Set<String>? expandedParents,
    Set<String>? loadingReplyParents,
    String? replyingToCommentId,
    String? replyingToUsername,
    bool clearReplyingTo = false,
    List<MentionUserEntity>? mentionSuggestions,
    bool? isSearchingMentions,
    String? pinnedCommentId,
    bool clearPinnedCommentId = false,
  }) {
    return CommentState(
      isLoadingInitial: isLoadingInitial ?? this.isLoadingInitial,
      isLoadingMore: isLoadingMore ?? this.isLoadingMore,
      isPosting: isPosting ?? this.isPosting,
      hasMore: hasMore ?? this.hasMore,
      errorMessage: errorMessage ?? this.errorMessage,
      comments: comments ?? this.comments,
      lastDocument: clearLastDocument ? null : (lastDocument ?? this.lastDocument),
      repliesByParent: repliesByParent ?? this.repliesByParent,
      expandedParents: expandedParents ?? this.expandedParents,
      loadingReplyParents: loadingReplyParents ?? this.loadingReplyParents,
      replyingToCommentId: clearReplyingTo ? null : (replyingToCommentId ?? this.replyingToCommentId),
      replyingToUsername: clearReplyingTo ? null : (replyingToUsername ?? this.replyingToUsername),
      mentionSuggestions: mentionSuggestions ?? this.mentionSuggestions,
      isSearchingMentions: isSearchingMentions ?? this.isSearchingMentions,
      pinnedCommentId: clearPinnedCommentId ? null : (pinnedCommentId ?? this.pinnedCommentId),
    );
  }

  factory CommentState.initial() => const CommentState();

  @override
  List<Object?> get props => [
        isLoadingInitial,
        isLoadingMore,
        isPosting,
        hasMore,
        errorMessage,
        comments,
        repliesByParent,
        expandedParents,
        loadingReplyParents,
        replyingToCommentId,
        replyingToUsername,
        mentionSuggestions,
        isSearchingMentions,
        pinnedCommentId,
      ];
}
