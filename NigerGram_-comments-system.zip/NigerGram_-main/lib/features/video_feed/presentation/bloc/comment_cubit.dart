// lib/features/video_feed/presentation/bloc/comment_cubit.dart
import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:nigergram/features/video_feed/domain/entities/comment_entity.dart';
import 'package:nigergram/features/video_feed/presentation/bloc/comment_state.dart';
import 'package:nigergram/features/video_feed/repository/interaction_repository.dart';

class CommentCubit extends Cubit<CommentState> {
  CommentCubit({
    required this.videoId,
    required this.videoCreatorId,
    InteractionRepository? interactionRepository,
    FirebaseFirestore? firestore,
    FirebaseAuth? firebaseAuth,
  })  : _repo = interactionRepository ?? InteractionRepository(),
        _firestore = firestore ?? FirebaseFirestore.instance,
        _auth = firebaseAuth ?? FirebaseAuth.instance,
        super(CommentState.initial()) {
    _subscribeComments();
  }

  final String videoId;
  final String videoCreatorId;
  final InteractionRepository _repo;
  final FirebaseFirestore _firestore;
  final FirebaseAuth _auth;

  static const int _pageSize = 20;
  int _currentLimit = _pageSize;

  StreamSubscription<QuerySnapshot>? _commentsSub;
  final Map<String, StreamSubscription<QuerySnapshot>> _replySubs = {};
  Timer? _mentionDebounce;
  int _mentionRequestId = 0;

  String? get currentUserId => _auth.currentUser?.uid;

  bool get isVideoCreator => currentUserId != null && currentUserId == videoCreatorId;

  @override
  Future<void> close() {
    _commentsSub?.cancel();
    for (final sub in _replySubs.values) {
      sub.cancel();
    }
    _mentionDebounce?.cancel();
    return super.close();
  }

  // ===================== TOP-LEVEL COMMENTS =====================

  void _subscribeComments() {
    emit(state.copyWith(isLoadingInitial: state.comments.isEmpty));
    _commentsSub?.cancel();
    _commentsSub = _repo.getCommentsStream(videoId, limit: _currentLimit).listen(
      (snapshot) {
        final comments = snapshot.docs.map((d) => CommentEntity.fromFirestore(d)).toList();
        String? pinned;
        for (final c in comments) {
          if (c.isPinned) {
            pinned = c.id;
            break;
          }
        }
        emit(state.copyWith(
          isLoadingInitial: false,
          isLoadingMore: false,
          comments: comments,
          hasMore: snapshot.docs.length >= _currentLimit,
          lastDocument: snapshot.docs.isNotEmpty ? snapshot.docs.last : null,
          pinnedCommentId: pinned,
          clearPinnedCommentId: pinned == null,
        ));
      },
      onError: (e) {
        emit(state.copyWith(isLoadingInitial: false, isLoadingMore: false, errorMessage: 'Failed to load comments'));
      },
    );
  }

  Future<void> loadMoreComments() async {
    if (state.isLoadingMore || !state.hasMore) return;
    emit(state.copyWith(isLoadingMore: true));
    _currentLimit += _pageSize;
    _subscribeComments();
  }

  // ===================== POSTING =====================

  Future<void> postComment(String rawText) async {
    final user = _auth.currentUser;
    final text = rawText.trim();
    if (user == null || text.isEmpty || state.isPosting) return;

    emit(state.copyWith(isPosting: true, errorMessage: ''));
    try {
      final profile = await _fetchCurrentUserProfile(user.uid);
      final mentioned = _extractMentions(text);

      await _repo.addComment(
        videoId,
        user.uid,
        profile.username,
        text,
        userAvatar: profile.avatar,
        parentId: state.replyingToCommentId,
        mentionedUsernames: mentioned,
      );

      emit(state.copyWith(isPosting: false, clearReplyingTo: true));
    } catch (e) {
      emit(state.copyWith(isPosting: false, errorMessage: 'Failed to post comment'));
    }
  }

  Future<_AuthorProfile> _fetchCurrentUserProfile(String uid) async {
    String username = '@NigerGram User';
    String avatar = '';
    try {
      final doc = await _firestore.collection('users').doc(uid).get();
      if (doc.exists) {
        final data = doc.data()!;
        avatar = data['profilePicUrl'] as String? ?? '';
        final uname = data['username'] as String?;
        final displayName = data['displayName'] as String?;
        final resolved = (uname != null && uname.isNotEmpty)
            ? uname
            : (displayName != null && displayName.isNotEmpty)
                ? displayName
                : null;
        if (resolved != null) {
          username = resolved.startsWith('@') ? resolved : '@$resolved';
        }
      }
    } catch (_) {}
    return _AuthorProfile(username: username, avatar: avatar);
  }

  List<String> _extractMentions(String text) {
    final matches = RegExp(r'@(\w+)').allMatches(text);
    return matches.map((m) => m.group(1)!).toSet().toList();
  }

  // ===================== REPLIES =====================

  void toggleReplies(String parentId) {
    final expanded = Set<String>.from(state.expandedParents);
    if (expanded.contains(parentId)) {
      expanded.remove(parentId);
      _replySubs.remove(parentId)?.cancel();
      emit(state.copyWith(expandedParents: expanded));
    } else {
      expanded.add(parentId);
      emit(state.copyWith(expandedParents: expanded));
      _subscribeReplies(parentId);
    }
  }

  void _subscribeReplies(String parentId) {
    final loading = Set<String>.from(state.loadingReplyParents)..add(parentId);
    emit(state.copyWith(loadingReplyParents: loading));

    _replySubs[parentId]?.cancel();
    _replySubs[parentId] = _repo.getRepliesStream(videoId, parentId).listen(
      (snapshot) {
        final replies = snapshot.docs.map((d) => CommentEntity.fromFirestore(d)).toList();
        final updatedMap = Map<String, List<CommentEntity>>.from(state.repliesByParent);
        updatedMap[parentId] = replies;
        final stillLoading = Set<String>.from(state.loadingReplyParents)..remove(parentId);
        emit(state.copyWith(repliesByParent: updatedMap, loadingReplyParents: stillLoading));
      },
      onError: (_) {
        final stillLoading = Set<String>.from(state.loadingReplyParents)..remove(parentId);
        emit(state.copyWith(loadingReplyParents: stillLoading));
      },
    );
  }

  void startReplyTo(String commentId, String username) {
    emit(state.copyWith(replyingToCommentId: commentId, replyingToUsername: username));
  }

  void cancelReply() {
    emit(state.copyWith(clearReplyingTo: true));
  }

  // ===================== LIKES =====================

  Future<void> toggleCommentLike(CommentEntity comment) async {
    final uid = currentUserId;
    if (uid == null) return;

    // Optimistic local update for the heart animation & count.
    _applyOptimisticLike(comment, uid);

    try {
      await _repo.toggleCommentLike(videoId, comment.id, uid);
      // Realtime listeners (top-level stream / reply stream) will reconcile
      // the authoritative state shortly after.
    } catch (_) {
      // Revert optimistic update on failure by re-applying the toggle.
      _applyOptimisticLike(comment, uid);
    }
  }

  void _applyOptimisticLike(CommentEntity comment, String uid) {
    final wasLiked = comment.isLikedBy(uid);
    final newLikedBy = List<String>.from(comment.likedBy);
    if (wasLiked) {
      newLikedBy.remove(uid);
    } else {
      newLikedBy.add(uid);
    }
    final updated = comment.copyWith(
      likedBy: newLikedBy,
      likeCount: (comment.likeCount + (wasLiked ? -1 : 1)).clamp(0, 1 << 31),
    );

    if (comment.parentId == null) {
      final list = state.comments.map((c) => c.id == comment.id ? updated : c).toList();
      emit(state.copyWith(comments: list));
    } else {
      final map = Map<String, List<CommentEntity>>.from(state.repliesByParent);
      final list = map[comment.parentId];
      if (list != null) {
        map[comment.parentId!] = list.map((c) => c.id == comment.id ? updated : c).toList();
        emit(state.copyWith(repliesByParent: map));
      }
    }
  }

  // ===================== DELETE =====================

  Future<bool> deleteComment(CommentEntity comment) async {
    final uid = currentUserId;
    if (uid == null) return false;
    try {
      await _repo.deleteComment(
        videoId: videoId,
        commentId: comment.id,
        requestingUserId: uid,
        requesterIsVideoCreator: isVideoCreator,
      );
      return true;
    } catch (e) {
      emit(state.copyWith(errorMessage: e.toString()));
      return false;
    }
  }

  bool canDelete(CommentEntity comment) {
    return currentUserId != null && (currentUserId == comment.userId || isVideoCreator);
  }

  // ===================== PIN =====================

  Future<void> pinComment(CommentEntity comment) async {
    if (!isVideoCreator) return;
    try {
      if (comment.isPinned) {
        await _repo.unpinComment(videoId: videoId, commentId: comment.id);
      } else {
        await _repo.pinComment(videoId: videoId, commentId: comment.id);
      }
    } catch (_) {
      emit(state.copyWith(errorMessage: 'Failed to update pin'));
    }
  }

  // ===================== REPORT =====================

  Future<bool> reportComment(CommentEntity comment, String reason) async {
    final uid = currentUserId;
    if (uid == null) return false;
    try {
      await _repo.reportComment(
        commentId: comment.id,
        videoId: videoId,
        reporterId: uid,
        reason: reason,
      );
      return true;
    } catch (_) {
      return false;
    }
  }

  // ===================== MENTIONS =====================

  void onComposerTextChanged(String text, int cursorPosition) {
    final upToCursor = text.substring(0, cursorPosition.clamp(0, text.length));
    final atIndex = upToCursor.lastIndexOf('@');
    if (atIndex == -1) {
      _clearMentionSuggestions();
      return;
    }
    final query = upToCursor.substring(atIndex + 1);
    // Stop suggesting once a space/newline ends the mention token.
    if (query.contains(' ') || query.contains('\n')) {
      _clearMentionSuggestions();
      return;
    }

    _mentionDebounce?.cancel();
    _mentionDebounce = Timer(const Duration(milliseconds: 250), () => _searchMentions(query));
  }

  void _clearMentionSuggestions() {
    if (state.mentionSuggestions.isNotEmpty || state.isSearchingMentions) {
      emit(state.copyWith(mentionSuggestions: const [], isSearchingMentions: false));
    }
  }

  Future<void> _searchMentions(String query) async {
    final requestId = ++_mentionRequestId;
    if (query.isEmpty) {
      emit(state.copyWith(mentionSuggestions: const [], isSearchingMentions: false));
      return;
    }
    emit(state.copyWith(isSearchingMentions: true));
    try {
      final snap = await _repo.searchUsernames(query);
      if (requestId != _mentionRequestId || isClosed) return;
      final users = snap.docs.map((d) => MentionUserEntity.fromFirestore(d)).toList();
      emit(state.copyWith(mentionSuggestions: users, isSearchingMentions: false));
    } catch (_) {
      if (requestId != _mentionRequestId || isClosed) return;
      emit(state.copyWith(mentionSuggestions: const [], isSearchingMentions: false));
    }
  }

  void clearMentionSuggestions() => _clearMentionSuggestions();
}

class _AuthorProfile {
  final String username;
  final String avatar;
  const _AuthorProfile({required this.username, required this.avatar});
}
