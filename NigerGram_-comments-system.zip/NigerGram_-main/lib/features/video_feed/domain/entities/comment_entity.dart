// lib/features/video_feed/domain/entities/comment_entity.dart
import 'package:cloud_firestore/cloud_firestore.dart';

/// Represents a single comment or reply on a video.
///
/// Top-level comments have [parentId] == null.
/// Replies have [parentId] set to the id of the top-level comment they
/// belong to. Replies are not nested any deeper than one level.
class CommentEntity {
  final String id;
  final String videoId;
  final String? parentId;
  final String userId;
  final String username;
  final String userAvatar;
  final String text;
  final List<String> mentionedUsernames;
  final DateTime createdAt;
  final int likeCount;
  final int replyCount;
  final bool isPinned;
  final List<String> likedBy;

  const CommentEntity({
    required this.id,
    required this.videoId,
    this.parentId,
    required this.userId,
    required this.username,
    required this.userAvatar,
    required this.text,
    this.mentionedUsernames = const [],
    required this.createdAt,
    this.likeCount = 0,
    this.replyCount = 0,
    this.isPinned = false,
    this.likedBy = const [],
  });

  bool get isReply => parentId != null;

  bool isLikedBy(String? userId) {
    if (userId == null || userId.isEmpty) return false;
    return likedBy.contains(userId);
  }

  factory CommentEntity.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    return CommentEntity(
      id: doc.id,
      videoId: data['videoId'] as String? ?? '',
      parentId: data['parentId'] as String?,
      userId: data['userId'] as String? ?? '',
      username: data['username'] as String? ?? 'User',
      userAvatar: data['userAvatar'] as String? ?? '',
      text: data['text'] as String? ?? '',
      mentionedUsernames: (data['mentionedUsernames'] as List<dynamic>?)
              ?.map((e) => e.toString())
              .toList() ??
          const [],
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      likeCount: (data['likeCount'] as num?)?.toInt() ?? 0,
      replyCount: (data['replyCount'] as num?)?.toInt() ?? 0,
      isPinned: data['isPinned'] as bool? ?? false,
      likedBy: (data['likedBy'] as List<dynamic>?)
              ?.map((e) => e.toString())
              .toList() ??
          const [],
    );
  }

  CommentEntity copyWith({
    int? likeCount,
    int? replyCount,
    bool? isPinned,
    List<String>? likedBy,
  }) {
    return CommentEntity(
      id: id,
      videoId: videoId,
      parentId: parentId,
      userId: userId,
      username: username,
      userAvatar: userAvatar,
      text: text,
      mentionedUsernames: mentionedUsernames,
      createdAt: createdAt,
      likeCount: likeCount ?? this.likeCount,
      replyCount: replyCount ?? this.replyCount,
      isPinned: isPinned ?? this.isPinned,
      likedBy: likedBy ?? this.likedBy,
    );
  }
}

/// Lightweight user record used for @mention autocomplete suggestions.
class MentionUserEntity {
  final String userId;
  final String username;
  final String avatarUrl;

  const MentionUserEntity({
    required this.userId,
    required this.username,
    required this.avatarUrl,
  });

  factory MentionUserEntity.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    return MentionUserEntity(
      userId: doc.id,
      username: data['username'] as String? ?? '',
      avatarUrl: data['profilePicUrl'] as String? ?? '',
    );
  }
}
