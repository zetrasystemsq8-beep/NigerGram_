// lib/features/upload/presentation/view/video_editor_screen.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:video_trimmer/video_trimmer.dart';
import 'package:nigergram/core/design_system/colors.dart';
import 'package:video_player/video_player.dart';

class OverlayItem {
  final String id;
  final String type;
  final String content;
  final double x;
  final double y;
  final double scale;
  final double rotation;
  final Color? textColor;
  final double? fontSize;

  OverlayItem({
    required this.id,
    required this.type,
    required this.content,
    this.x = 0.5,
    this.y = 0.5,
    this.scale = 1.0,
    this.rotation = 0.0,
    this.textColor,
    this.fontSize,
  });

  OverlayItem copyWith({
    String? id,
    String? type,
    String? content,
    double? x,
    double? y,
    double? scale,
    double? rotation,
    Color? textColor,
    double? fontSize,
  }) {
    return OverlayItem(
      id: id ?? this.id,
      type: type ?? this.type,
      content: content ?? this.content,
      x: x ?? this.x,
      y: y ?? this.y,
      scale: scale ?? this.scale,
      rotation: rotation ?? this.rotation,
      textColor: textColor ?? this.textColor,
      fontSize: fontSize ?? this.fontSize,
    );
  }
}

class VideoEditorScreen extends StatefulWidget {
  final File videoFile;

  const VideoEditorScreen({super.key, required this.videoFile});

  @override
  State<VideoEditorScreen> createState() => _VideoEditorScreenState();
}

class _VideoEditorScreenState extends State<VideoEditorScreen> {
  final Trimmer _trimmer = Trimmer();
  bool _isTrimming = false;
  bool _isPlaying = false;
  double _startValue = 0.0;
  double _endValue = 1.0;
  VideoPlayerController? _controller;
  File? _trimmedFile;

  final List<OverlayItem> _overlays = [];
  String _selectedTool = 'trim';
  final TextEditingController _textController = TextEditingController();
  Color _selectedTextColor = Colors.white;
  double _selectedFontSize = 24;

  @override
  void initState() {
    super.initState();
    _loadVideo();
  }

  @override
  void dispose() {
    _trimmer.dispose();
    _textController.dispose();
    super.dispose();
  }

  Future<void> _loadVideo() async {
    await _trimmer.loadVideo(videoFile: widget.videoFile);
    _controller = _trimmer.videoPlayerController;
    setState(() {});
  }

  // ✅ FIXED for video_trimmer v5.0.0 - uses milliseconds not 0-1 values
  Future<void> _trimVideo() async {
    if (_controller == null) return;
    setState(() => _isTrimming = true);
    try {
      final duration = _controller!.value.duration.inMilliseconds.toDouble();
      await _trimmer.saveTrimmedVideo(
        startValue: _startValue * duration,
        endValue: _endValue * duration,
        onSave: (outputPath) {
          if (outputPath != null && outputPath.isNotEmpty) {
            setState(() => _trimmedFile = File(outputPath));
          }
          setState(() => _isTrimming = false);
        },
      );
    } catch (e) {
      setState(() => _isTrimming = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Trim failed: $e'),
            backgroundColor: NGColors.error,
          ),
        );
      }
    }
  }

  void _togglePlay() {
    if (_controller == null) return;
    setState(() {
      if (_controller!.value.isPlaying) {
        _controller!.pause();
        _isPlaying = false;
      } else {
        _controller!.play();
        _isPlaying = true;
      }
    });
  }

  void _addEmoji(String emoji) {
    setState(() {
      _overlays.add(OverlayItem(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        type: 'emoji',
        content: emoji,
        x: 0.5,
        y: 0.5,
        scale: 1.0,
      ));
    });
  }

  void _addTextOverlay() {
    if (_textController.text.trim().isEmpty) return;
    setState(() {
      _overlays.add(OverlayItem(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        type: 'text',
        content: _textController.text.trim(),
        x: 0.5,
        y: 0.5,
        scale: 1.0,
        textColor: _selectedTextColor,
        fontSize: _selectedFontSize,
      ));
    });
    _textController.clear();
  }

  void _removeOverlay(String id) {
    setState(() => _overlays.removeWhere((item) => item.id == id));
  }

  void _updateOverlayPosition(String id, double x, double y) {
    setState(() {
      final index = _overlays.indexWhere((item) => item.id == id);
      if (index != -1) {
        _overlays[index] = _overlays[index].copyWith(x: x, y: y);
      }
    });
  }

  void _updateOverlayScale(String id, double scale) {
    setState(() {
      final index = _overlays.indexWhere((item) => item.id == id);
      if (index != -1) {
        _overlays[index] = _overlays[index].copyWith(scale: scale);
      }
    });
  }

  void _saveAndReturn() {
    final fileToReturn = _trimmedFile ?? widget.videoFile;
    Navigator.pop(context, fileToReturn);
  }

  void _showEmojiPicker() {
    const emojis = [
      '😂', '😍', '🔥', '💯', '🥺', '😭', '❤️', '🙏',
      '🇳🇬', '🎉', '✨', '💪', '👀', '🤣', '😱', '🥰',
      '😎', '🤔', '💀', '👏', '🙌', '💖', '😘', '🥳',
      '😊', '🤗', '😇', '🤩', '😤', '😒', '💔', '😡',
      '👊', '🤝', '👍', '👎', '✌️', '🤞', '👌', '💯',
    ];

    showModalBottomSheet(
      context: context,
      backgroundColor: NGColors.background,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => Container(
        height: 300,
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Add Emoji',
              style: TextStyle(
                color: NGColors.textPrimary,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 8,
                ),
                itemCount: emojis.length,
                itemBuilder: (_, i) => GestureDetector(
                  onTap: () {
                    _addEmoji(emojis[i]);
                    Navigator.pop(ctx);
                  },
                  child: Container(
                    margin: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: NGColors.surface,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Center(
                      child: Text(
                        emojis[i],
                        style: const TextStyle(fontSize: 28),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showTextOverlaySheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: NGColors.background,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(ctx).viewInsets.bottom,
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Add Text Overlay',
                style: TextStyle(
                  color: NGColors.textPrimary,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _textController,
                style: const TextStyle(color: NGColors.textPrimary, fontSize: 16),
                decoration: InputDecoration(
                  hintText: 'Type your text...',
                  hintStyle: const TextStyle(color: NGColors.textMuted),
                  filled: true,
                  fillColor: NGColors.surface,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                ),
                autofocus: true,
              ),
              const SizedBox(height: 16),
              const Text(
                'Color',
                style: TextStyle(color: NGColors.textSecondary, fontSize: 14),
              ),
              const SizedBox(height: 8),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    _colorChip(Colors.white),
                    _colorChip(Colors.black),
                    _colorChip(Colors.red),
                    _colorChip(Colors.green),
                    _colorChip(Colors.blue),
                    _colorChip(Colors.yellow),
                    _colorChip(Colors.purple),
                    _colorChip(Colors.orange),
                    _colorChip(Colors.pink),
                    _colorChip(NGColors.accent),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'Size: ${_selectedFontSize.toInt()}',
                style: const TextStyle(color: NGColors.textSecondary, fontSize: 14),
              ),
              Slider(
                value: _selectedFontSize,
                min: 14,
                max: 60,
                activeColor: NGColors.accent,
                inactiveColor: NGColors.divider,
                onChanged: (v) => setState(() => _selectedFontSize = v),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    _addTextOverlay();
                    Navigator.pop(ctx);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: NGColors.accent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: const Text(
                    'Add Text',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _colorChip(Color color) {
    return GestureDetector(
      onTap: () => setState(() => _selectedTextColor = color),
      child: Container(
        margin: const EdgeInsets.only(right: 8),
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: Border.all(
            color: _selectedTextColor == color
                ? NGColors.accent
                : NGColors.divider,
            width: _selectedTextColor == color ? 3 : 1,
          ),
        ),
      ),
    );
  }

  Widget _toolButton(
    IconData icon,
    String label,
    bool isSelected,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: isSelected
                  ? NGColors.accent.withOpacity(0.15)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isSelected ? NGColors.accent : NGColors.divider,
              ),
            ),
            child: Icon(
              icon,
              color: isSelected ? NGColors.accent : NGColors.textMuted,
              size: 22,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: isSelected ? NGColors.accent : NGColors.textMuted,
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NGColors.background,
      appBar: AppBar(
        backgroundColor: NGColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.close, color: NGColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Edit Video',
          style: TextStyle(
            color: NGColors.textPrimary,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          TextButton(
            onPressed: (_trimmedFile != null || _overlays.isNotEmpty)
                ? _saveAndReturn
                : null,
            child: Text(
              'Apply',
              style: TextStyle(
                color: (_trimmedFile != null || _overlays.isNotEmpty)
                    ? NGColors.accent
                    : NGColors.textMuted,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ),
        ],
      ),
      body: _controller == null
          ? const Center(
              child: CircularProgressIndicator(color: NGColors.accent),
            )
          : Column(
              children: [
                Expanded(
                  flex: 3,
                  child: Stack(
                    children: [
                      Container(
                        color: NGColors.surface,
                        child: Center(
                          child: AspectRatio(
                            aspectRatio: _controller!.value.aspectRatio,
                            child: VideoPlayer(_controller!),
                          ),
                        ),
                      ),
                      ..._overlays.map((item) {
                        return Positioned(
                          left: item.x * MediaQuery.of(context).size.width - 50,
                          top: item.y *
                                  (MediaQuery.of(context).size.height * 0.6) -
                              50,
                          child: GestureDetector(
                            onTap: () => _removeOverlay(item.id),
                            onPanUpdate: (details) {
                              _updateOverlayPosition(
                                item.id,
                                (item.x +
                                        details.delta.dx /
                                            MediaQuery.of(context).size.width)
                                    .clamp(0.0, 1.0),
                                (item.y +
                                        details.delta.dy /
                                            (MediaQuery.of(context).size.height *
                                                0.6))
                                    .clamp(0.0, 1.0),
                              );
                            },
                            onScaleUpdate: (details) {
                              _updateOverlayScale(
                                item.id,
                                (item.scale * details.scale).clamp(0.5, 3.0),
                              );
                            },
                            child: Transform.scale(
                              scale: item.scale,
                              child: Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                    color: Colors.white.withOpacity(0.3),
                                    width: 1,
                                  ),
                                ),
                                child: item.type == 'emoji'
                                    ? Text(
                                        item.content,
                                        style:
                                            const TextStyle(fontSize: 40),
                                      )
                                    : Text(
                                        item.content,
                                        style: TextStyle(
                                          color:
                                              item.textColor ?? Colors.white,
                                          fontSize: item.fontSize ?? 24,
                                          fontWeight: FontWeight.bold,
                                          shadows: const [
                                            Shadow(
                                              color: Colors.black87,
                                              blurRadius: 4,
                                              offset: Offset(0, 2),
                                            ),
                                          ],
                                        ),
                                      ),
                              ),
                            ),
                          ),
                        );
                      }),
                      Center(
                        child: GestureDetector(
                          onTap: _togglePlay,
                          child: Container(
                            width: 60,
                            height: 60,
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.5),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              _isPlaying
                                  ? Icons.pause_rounded
                                  : Icons.play_arrow_rounded,
                              color: NGColors.textPrimary,
                              size: 36,
                            ),
                          ),
                        ),
                      ),
                      if (_overlays.isNotEmpty)
                        Positioned(
                          top: 8,
                          right: 8,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: NGColors.accent.withOpacity(0.9),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              '${_overlays.length} overlays',
                              style: const TextStyle(
                                color: NGColors.textPrimary,
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                  decoration: const BoxDecoration(
                    color: NGColors.surface,
                    border: Border(
                      top: BorderSide(color: NGColors.divider, width: 1),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _toolButton(
                        Icons.cut,
                        'Trim',
                        _selectedTool == 'trim',
                        () => setState(() => _selectedTool = 'trim'),
                      ),
                      _toolButton(
                        Icons.emoji_emotions,
                        'Emoji',
                        _selectedTool == 'emoji',
                        () {
                          setState(() => _selectedTool = 'emoji');
                          _showEmojiPicker();
                        },
                      ),
                      _toolButton(
                        Icons.text_fields,
                        'Text',
                        _selectedTool == 'text',
                        () {
                          setState(() => _selectedTool = 'text');
                          _showTextOverlaySheet();
                        },
                      ),
                      _toolButton(
                        Icons.delete_outline,
                        'Clear All',
                        false,
                        () {
                          if (_overlays.isNotEmpty) {
                            setState(() => _overlays.clear());
                          }
                        },
                      ),
                    ],
                  ),
                ),
                if (_selectedTool == 'trim')
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                    decoration: BoxDecoration(
                      color: NGColors.surfaceLight,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    margin: const EdgeInsets.all(12),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            const Text(
                              'Trim Video',
                              style: TextStyle(
                                color: NGColors.textPrimary,
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                              ),
                            ),
                            const Spacer(),
                            if (_trimmedFile != null)
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: NGColors.success.withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: NGColors.success.withOpacity(0.3),
                                  ),
                                ),
                                child: const Text(
                                  'Trimmed ✓',
                                  style: TextStyle(
                                    color: NGColors.success,
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        RangeSlider(
                          values: RangeValues(_startValue, _endValue),
                          min: 0.0,
                          max: 1.0,
                          activeColor: NGColors.accent,
                          inactiveColor: NGColors.divider,
                          onChanged: (values) {
                            setState(() {
                              _startValue = values.start;
                              _endValue = values.end;
                            });
                          },
                        ),
                        const Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Start',
                              style: TextStyle(
                                color: NGColors.textMuted,
                                fontSize: 12,
                              ),
                            ),
                            Text(
                              'End',
                              style: TextStyle(
                                color: NGColors.textMuted,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Expanded(
                              child: OutlinedButton(
                                onPressed: () {
                                  setState(() {
                                    _startValue = 0.0;
                                    _endValue = 1.0;
                                    _trimmedFile = null;
                                  });
                                },
                                style: OutlinedButton.styleFrom(
                                  side: const BorderSide(
                                    color: NGColors.divider,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                ),
                                child: const Text(
                                  'Reset',
                                  style: TextStyle(
                                    color: NGColors.textSecondary,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: ElevatedButton(
                                onPressed: _isTrimming ? null : _trimVideo,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: NGColors.accent,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                ),
                                child: _isTrimming
                                    ? const SizedBox(
                                        width: 16,
                                        height: 16,
                                        child: CircularProgressIndicator(
                                          color: Colors.white,
                                          strokeWidth: 2,
                                        ),
                                      )
                                    : const Text(
                                        'Trim',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
              ],
            ),
    );
  }
}
